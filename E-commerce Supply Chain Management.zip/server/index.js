const express=require('express');
const cors=require('cors');
const {MongoClient}=require('mongodb');

const app=new express();
app.use(express.json());
app.use(cors());

app.get('/home',(req,res)=>{
    res.send("home page")
})
const client=new MongoClient('mongodb+srv://admin:admin@cluster0.zoizwub.mongodb.net/?retryWrites=true&w=majority')
client.connect();
const db=client.db('cvms');
const col=db.collection('registration details');

app.post('/insert', (req, res) => {
    console.logo(req.body);
    col.insertOne(req.body);
        res.send("suuccessfully received");
})

app.post('/update',async(req,res)=>{
    console.logo(req.body)
    const {un,pw,ro,em}=req.body
    await col.updateOne({name:un},{
        $set:{
            password:pw,
            role:ro,
            email:em
        }
    })
})

app.get('/showall',async(req,res)=>{
    const result=await col.find().toArray();
    res.send(result)
})

app.post('/delete',async(req,res)=>{
    const result1=await col.findOne({'name':req.body.un});
    console.log(result1);
    if (result1.password==req.body.pw){
        col.deleteOne(result1);
        console.log("deleted")
    }
   
})

app.listen(8081);
console.log("server running");